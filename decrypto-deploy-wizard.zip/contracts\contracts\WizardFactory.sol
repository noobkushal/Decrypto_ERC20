// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {MyToken} from "./MyToken.sol";
import {TokenVesting} from "./TokenVesting.sol";

contract WizardFactory {
    event WizardDeployed(
        address indexed founder,
        address tokenAddress,
        address vestingAddress,
        string tokenName,
        string tokenSymbol,
        uint256 initialSupply,
        address beneficiary,
        uint64 cliffSeconds,
        uint64 durationSeconds
    );

    function deployWizard(
        string memory name,
        string memory symbol,
        uint256 supply,
        address beneficiary,
        uint64 cliffSeconds,
        uint64 durationSeconds
    ) external returns (address token, address vesting) {
        TokenVesting vestingContract = new TokenVesting(
            beneficiary,
            uint64(block.timestamp),
            cliffSeconds,
            durationSeconds
        );

        MyToken tokenContract = new MyToken(
            name,
            symbol,
            supply,
            msg.sender, // founder is the owner
            address(vestingContract) // The vesting contract gets the initial supply
        );

        emit WizardDeployed(
            msg.sender,
            address(tokenContract),
            address(vestingContract),
            name,
            symbol,
            supply,
            beneficiary,
            cliffSeconds,
            durationSeconds
        );

        return (address(tokenContract), address(vestingContract));
    }
}
