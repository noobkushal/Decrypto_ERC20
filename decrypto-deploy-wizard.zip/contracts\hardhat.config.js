import "dotenv/config";
import ignitionEthers from "@nomicfoundation/hardhat-ignition-ethers";
import ignition from "@nomicfoundation/hardhat-ignition";

/** @type {import('hardhat/config').HardhatUserConfig} */
export default {
  solidity: "0.8.20",
  plugins: [ignitionEthers, ignition],
  networks: {
    sepolia: {
      type: "http",
      url: process.env.SEPOLIA_RPC_URL || "",
      accounts: process.env.PRIVATE_KEY ? [process.env.PRIVATE_KEY] : [],
    },
  },
};