"use client";

import { useState, useEffect, useRef } from "react";
import { db } from "@/lib/firebase";
import { collection, query, orderBy, onSnapshot } from "firebase/firestore";
import { 
  Zap, 
  ShieldCheck, 
  Activity, 
  Clock, 
  Plus, 
  Filter, 
  Download, 
  ExternalLink,
  ChevronRight,
  Database
} from "lucide-react";
import { ethers } from "ethers";
import Link from "next/link";
import NetworkSettings from "@/components/NetworkSettings";

export default function ArchivePage() {
  const [deployments, setDeployments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [blockNumber, setBlockNumber] = useState("SYNCING...");
  const [activeTab, setActiveTab] = useState("overview");
  const fetchCount = useRef(0);

  useEffect(() => {
    let isMounted = true;
    const fetchBlock = async () => {
      if (fetchCount.current > 0) return;
      fetchCount.current++;

      try {
        const provider = new ethers.JsonRpcProvider("https://rpc.ankr.com/eth_sepolia", undefined, { staticNetwork: true });
        
        const blockPromise = provider.getBlockNumber();
        const timeoutPromise = new Promise((_, reject) => 
          setTimeout(() => reject(new Error("Timeout")), 3000)
        );

        const block = await Promise.race([blockPromise, timeoutPromise]);
        if (isMounted) setBlockNumber(`#${block.toLocaleString()}`);
      } catch (e) {
        if (isMounted) setBlockNumber("OFFLINE");
      } finally {
        fetchCount.current--;
      }
    };

    fetchBlock();
    const interval = setInterval(fetchBlock, 30000); // 30 seconds
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  useEffect(() => {
    const q = query(collection(db, "deployments"), orderBy("timestamp", "desc"));
    
    // Safety check for Firestore onSnapshot
    const unsubscribe = onSnapshot(q, 
      (snapshot) => {
        const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setDeployments(data);
        setLoading(false);
      },
      (error) => {
        console.error("Firebase error:", error);
        setLoading(false);
      }
    );
    
    return () => unsubscribe();
  }, []);

  return (
    <div className="space-y-12 pb-24 page-fade-in">
      {/* Header */}
      <header className="flex justify-between items-end">
        <div className="space-y-2">
          <div className="text-[10px] font-black uppercase tracking-widest text-industrial-gray-500">Secure Infrastructure</div>
          <h1 className="heading-lg">Vault Dashboard</h1>
        </div>
        
        <div className="flex gap-16">
           <div className="space-y-1">
              <div className="text-[8px] font-black uppercase tracking-widest text-industrial-gray-500">Total Value Deployed</div>
              <div className="text-2xl font-black italic">$1,284,902.44</div>
           </div>
           <div className="space-y-1">
              <div className="text-[8px] font-black uppercase tracking-widest text-industrial-gray-500">System Health</div>
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-tight text-industrial-emerald">
                 <div className="w-2 h-2 rounded-full bg-industrial-emerald" />
                 Operational
              </div>
           </div>
        </div>
      </header>

      {/* Tab Navigation */}
      <div className="flex gap-12 border-b border-industrial-gray-200">
        {["overview", "settings"].map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`pb-4 text-[10px] font-black uppercase tracking-widest transition-all border-b-2 ${
              activeTab === tab ? "text-black border-black" : "text-industrial-gray-400 border-transparent hover:text-black"
            }`}
          >
            {tab === "overview" ? "Vault Overview" : "Signer Settings"}
          </button>
        ))}
      </div>

      {activeTab === "overview" ? (
        <>
          {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
         <div className="industrial-card p-8 space-y-4">
            <Database className="w-5 h-5 text-industrial-gray-500" />
            <div className="space-y-1">
               <div className="text-[10px] font-black uppercase tracking-widest text-industrial-gray-500">Active Contracts</div>
               <div className="text-4xl font-black italic">42</div>
            </div>
         </div>
         <div className="industrial-card p-8 space-y-4">
            <Clock className="w-5 h-5 text-industrial-gray-500" />
            <div className="space-y-1">
               <div className="text-[10px] font-black uppercase tracking-widest text-industrial-gray-500">Deployments (24H)</div>
               <div className="text-4xl font-black italic">18</div>
            </div>
         </div>
         <div className="industrial-card p-8 space-y-4">
            <ShieldCheck className="w-5 h-5 text-industrial-gray-500" />
            <div className="space-y-1">
               <div className="text-[10px] font-black uppercase tracking-widest text-industrial-gray-500">Verification Rate</div>
               <div className="text-4xl font-black italic">100%</div>
            </div>
         </div>
         <Link href="/deploy/wizard" className="bg-black p-8 flex flex-col justify-between group hover:bg-industrial-gray-900 transition-all">
            <Plus className="w-8 h-8 text-white group-hover:rotate-90 transition-transform duration-500" />
            <div className="space-y-1">
               <div className="text-[10px] font-black uppercase tracking-widest text-white/40">New Deployment</div>
               <div className="text-2xl font-black italic text-white uppercase tracking-tighter">Initiate Vault</div>
            </div>
         </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
         <div className="lg:col-span-2 space-y-8">
            <div className="flex justify-between items-center">
               <h2 className="heading-md">Recent Deployments</h2>
               <div className="flex gap-4">
                  <button className="p-2 industrial-card"><Filter className="w-4 h-4" /></button>
                  <button className="p-2 industrial-card"><Download className="w-4 h-4" /></button>
               </div>
            </div>

            <div className="industrial-card overflow-hidden">
               <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-industrial-gray-100">
                      <th className="px-8 py-4 text-[8px] font-black uppercase tracking-widest text-industrial-gray-500">Contract Name</th>
                      <th className="px-8 py-4 text-[8px] font-black uppercase tracking-widest text-industrial-gray-500">Address</th>
                      <th className="px-8 py-4 text-[8px] font-black uppercase tracking-widest text-industrial-gray-500">Timestamp</th>
                      <th className="px-8 py-4 text-[8px] font-black uppercase tracking-widest text-industrial-gray-500">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-industrial-gray-100">
                    {loading ? (
                       <tr>
                         <td colSpan={4} className="px-8 py-12 text-center">
                            <div className="flex items-center justify-center gap-3 text-xs font-black uppercase tracking-widest text-industrial-gray-500">
                               <div className="w-2 h-2 rounded-full bg-industrial-gray-500 animate-pulse" />
                               Decryption in Progress...
                            </div>
                         </td>
                       </tr>
                    ) : deployments.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="px-8 py-12 text-center text-xs font-bold text-industrial-gray-500 uppercase tracking-widest">
                          No deployment logs found in encrypted sector
                        </td>
                      </tr>
                    ) : (
                      deployments.map((d) => (
                        <tr key={d.id} className="hover:bg-industrial-gray-50 transition-colors group">
                          <td className="px-8 py-6">
                             <div className="font-black italic uppercase text-sm tracking-tight">{d.tokenName}</div>
                             <div className="text-[9px] font-bold text-industrial-gray-500 uppercase">{d.tokenSymbol}</div>
                          </td>
                          <td className="px-8 py-6">
                             <div className="flex items-center gap-2 bg-industrial-gray-100 px-2 py-1 text-[10px] font-mono font-bold text-industrial-gray-500 w-fit">
                                {d.tokenAddress?.slice(0, 10)}...
                             </div>
                          </td>
                          <td className="px-8 py-6 text-xs font-bold text-industrial-gray-500">
                             {d.timestamp?.toDate ? d.timestamp.toDate().toLocaleString('en-US', { 
                                year: 'numeric', 
                                month: '2-digit', 
                                day: '2-digit', 
                                hour: '2-digit', 
                                minute: '2-digit',
                                hour12: false 
                             }) : 'Pending...'}
                          </td>
                          <td className="px-8 py-6">
                             <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-industrial-emerald">
                                <div className="w-1.5 h-1.5 rounded-full bg-industrial-emerald" />
                                Verified
                             </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
               </table>
            </div>
         </div>

         <aside className="space-y-8">
            <div className="industrial-card p-8 space-y-8">
               <h3 className="text-[10px] font-black uppercase tracking-widest text-black">Network Pulse</h3>
               
               <div className="space-y-8">
                  {[
                    { title: "Block Height Sync", desc: `Connected to Sepolia. Block ${blockNumber} processed.`, time: "JUST NOW" },
                    { title: "Audit Snapshot", desc: "Periodic security scan completed. No anomalies detected in current active vaults.", time: "14 MINS AGO" },
                    { title: "Gas Optimization", desc: "Auto-scaling reduced deployment costs by 12% for the last epoch.", time: "2 HOURS AGO" }
                  ].map((pulse) => (
                    <div key={pulse.title} className="flex gap-4 border-l-2 border-industrial-emerald pl-6 relative">
                       <div className="space-y-2">
                          <h4 className="text-xs font-black uppercase tracking-tight">{pulse.title}</h4>
                          <p className="text-[10px] text-industrial-gray-500 font-medium leading-relaxed">{pulse.desc}</p>
                          <div className="text-[8px] font-black text-industrial-gray-500">{pulse.time}</div>
                       </div>
                    </div>
                  ))}
               </div>
            </div>

            <div className="bg-black aspect-video relative overflow-hidden p-8 flex flex-col justify-end text-white">
               <div className="space-y-1 relative z-10">
                  <div className="text-[8px] font-black uppercase tracking-widest opacity-40">Security Protocol</div>
                  <div className="text-3xl font-black italic uppercase tracking-tighter leading-none">Quantum Resistance <br /> Active</div>
               </div>
               <div className="absolute inset-0 opacity-40 bg-[url('https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=2070&auto=format&fit=crop')] bg-cover" />
               <div className="absolute top-0 right-0 p-8 opacity-20">
                  <ShieldCheck className="w-20 h-20" />
               </div>
            </div>
         </aside>
      </div>
      </>
      ) : (
        <div className="max-w-4xl">
          <NetworkSettings />
        </div>
      )}
    </div>
  );
}
