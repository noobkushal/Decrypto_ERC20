"use client";

import { useState, useEffect } from "react";
import { ShieldAlert, RefreshCw } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const SEPOLIA_CHAIN_ID = "0xaa36a7"; // 11155111

export default function NetworkWrapper({ children }) {
  const [isCorrectNetwork, setIsCorrectNetwork] = useState(true);
  const [hasProvider, setHasProvider] = useState(false);

  useEffect(() => {
    if (typeof window !== "undefined" && window.ethereum) {
      setHasProvider(true);
      
      const checkNetwork = async () => {
        const chainId = await window.ethereum.request({ method: "eth_chainId" });
        setIsCorrectNetwork(chainId === SEPOLIA_CHAIN_ID);
      };

      checkNetwork();

      window.ethereum.on("chainChanged", (chainId) => {
        setIsCorrectNetwork(chainId === SEPOLIA_CHAIN_ID);
      });
    }
  }, []);

  const switchToSepolia = async () => {
    try {
      await window.ethereum.request({
        method: "wallet_switchEthereumChain",
        params: [{ chainId: SEPOLIA_CHAIN_ID }],
      });
    } catch (switchError) {
      // This error code indicates that the chain has not been added to MetaMask.
      if (switchError.code === 4902) {
        try {
          await window.ethereum.request({
            method: "wallet_addEthereumChain",
            params: [{
              chainId: SEPOLIA_CHAIN_ID,
              chainName: "Sepolia Test Network",
              nativeCurrency: { name: "Sepolia ETH", symbol: "ETH", decimals: 18 },
              rpcUrls: ["https://sepolia.infura.io/v3/"],
              blockExplorerUrls: ["https://sepolia.etherscan.io"],
            }],
          });
        } catch (addError) {
          console.error(addError);
        }
      }
    }
  };

  if (!hasProvider) return children;

  return (
    <>
      <AnimatePresence>
        {!isCorrectNetwork && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-md p-6"
          >
            <div className="max-w-md w-full glass p-8 rounded-3xl border border-neon-crimson/30 text-center space-y-6 shadow-[0_0_50px_rgba(255,0,60,0.2)]">
              <div className="flex justify-center">
                <div className="w-20 h-20 rounded-full bg-neon-crimson/10 flex items-center justify-center border border-neon-crimson/50 animate-pulse">
                  <ShieldAlert className="w-10 h-10 text-neon-crimson" />
                </div>
              </div>
              
              <div className="space-y-2">
                <h2 className="text-3xl font-black italic uppercase text-neon-crimson tracking-tighter">Access Denied</h2>
                <p className="text-white/60 text-sm font-medium">Unauthorized network detected. Our operations are strictly confined to the <span className="text-neon-cyan">Sepolia</span> testnet.</p>
              </div>

              <button 
                onClick={switchToSepolia}
                className="w-full py-4 rounded-xl bg-neon-crimson text-black font-black uppercase tracking-widest hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-3"
              >
                <RefreshCw className="w-5 h-5" />
                Switch to Sepolia
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      {children}
    </>
  );
}
