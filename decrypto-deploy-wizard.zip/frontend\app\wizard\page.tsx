"use client";

import { useState, useEffect } from "react";
import { ethers } from "ethers";
import { db } from "@/lib/firebase";
import { collection, addDoc, serverTimestamp, query, orderBy, onSnapshot } from "firebase/firestore";
import { WIZARD_FACTORY_ABI } from "@/lib/constants";
import { useWallet } from "@/context/WalletContext";
import { Rocket, Wallet, Loader2, Zap, ArrowLeft, ArrowRight, ShieldCheck, PenLine, Plus, Terminal, CheckCircle2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const FACTORY_ADDRESS = "0xA352674cb6530234447cC8DBeeA03e45C65fDC9C";

export default function DeployPage() {
  const { account, connectWallet, systemConfig } = useWallet();
  const [useSystemSigner, setUseSystemSigner] = useState(false);
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(1);
  const [status, setStatus] = useState({ type: "", message: "" });
  
  const [formData, setFormData] = useState({
    name: "Industrial Protocol",
    symbol: "INDS",
    supply: "100000000",
    decimals: "18",
    beneficiary: account || "",
    cliff: "3600",
    duration: "86400",
  });

  useEffect(() => {
    if (account) {
      setFormData(prev => ({ ...prev, beneficiary: account }));
    }
  }, [account]);

  const handleDeploy = async () => {
    if (!account) return connectWallet();
    
    setLoading(true);
    setStatus({ type: "info", message: "Initializing deployment sequence..." });

    try {
      let signer;
      if (useSystemSigner) {
        if (!systemConfig.rpcUrl) throw new Error("System RPC URL not configured in Dashboard settings.");
        const provider = new ethers.JsonRpcProvider(systemConfig.rpcUrl);
        // We fetch the PK again from the API for the actual signing
        const configRes = await fetch("/api/config");
        const configData = await configRes.json();
        if (!configData.privateKey || configData.privateKey === "********") throw new Error("Private Key not configured or inaccessible.");
        signer = new ethers.Wallet(configData.privateKey, provider);
      } else {
        const provider = new ethers.BrowserProvider(window.ethereum);
        signer = await provider.getSigner();
      }

      const factory = new ethers.Contract(FACTORY_ADDRESS, WIZARD_FACTORY_ABI, signer);

      const tx = await factory.deployWizard(
        formData.name,
        formData.symbol,
        ethers.parseUnits(formData.supply, 18),
        formData.beneficiary,
        parseInt(formData.cliff),
        parseInt(formData.duration)
      );

      setStatus({ type: "info", message: "Transaction pending..." });
      const receipt = await tx.wait();

      const event = receipt.logs.find(log => {
        try {
          return factory.interface.parseLog(log)?.name === "WizardDeployed";
        } catch (e) { return false; }
      });

      if (event) {
        const decoded = factory.interface.parseLog(event);
        const { tokenAddress, vestingAddress } = decoded.args;

        await addDoc(collection(db, "deployments"), {
          tokenName: formData.name,
          tokenSymbol: formData.symbol,
          tokenAddress,
          vestingAddress,
          founder: account,
          beneficiary: formData.beneficiary,
          initialSupply: formData.supply,
          cliff: formData.cliff,
          duration: formData.duration,
          timestamp: serverTimestamp(),
          txHash: tx.hash
        });

        setStatus({ type: "success", message: `Deployment Successful! Address: ${tokenAddress?.slice(0, 8)}...` });
      }
    } catch (err: any) {
      console.error(err);
      setStatus({ type: "error", message: err.reason || err.message || "Deployment failed" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-12 pb-24">
      {/* Header */}
      <header className="flex justify-between items-end">
        <div className="space-y-2">
          <div className="text-[10px] font-black uppercase tracking-widest text-industrial-gray-500">Asset Generation</div>
          <h1 className="heading-lg">Forge Wizard</h1>
        </div>
        
        <div className="flex gap-12">
          {["Parameters", "Vesting", "Review"].map((s, i) => (
             <button 
               key={s} 
               onClick={() => setStep(i + 1)}
               className="flex flex-col gap-1 text-left group transition-all"
             >
                <div className={`text-[10px] font-black uppercase tracking-widest ${step === i + 1 ? 'text-black' : 'text-industrial-gray-500 group-hover:text-black'}`}>
                   0{i + 1}. {s}
                </div>
                <div className={`h-1 w-48 ${step === i + 1 ? 'bg-black' : 'bg-industrial-gray-200 group-hover:bg-industrial-gray-400'}`} />
             </button>
          ))}
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
        {/* Form Column */}
        <div className="lg:col-span-2 space-y-16">
          {/* Core Identity */}
          <section className="space-y-8">
            <div className="space-y-2">
              <h2 className="heading-md">Core Identity</h2>
              <p className="text-xs text-industrial-gray-500 font-medium">Define the foundational properties of your smart contract asset. These cannot be changed after deployment.</p>
            </div>

            <div className="grid grid-cols-2 gap-x-8 gap-y-6">
               <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-industrial-gray-500">Asset Name</label>
                  <input 
                    type="text" 
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    placeholder="e.g. Industrial Protocol" 
                    className="industrial-input" 
                  />
               </div>
               <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-industrial-gray-500">Ticker Symbol</label>
                  <input 
                    type="text" 
                    value={formData.symbol}
                    onChange={(e) => setFormData({...formData, symbol: e.target.value})}
                    placeholder="e.g. INDS" 
                    className="industrial-input" 
                  />
               </div>
               <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-industrial-gray-500">Initial Supply</label>
                  <input 
                    type="text" 
                    value={formData.supply}
                    onChange={(e) => setFormData({...formData, supply: e.target.value})}
                    placeholder="100,000,000" 
                    className="industrial-input" 
                  />
               </div>
               <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-industrial-gray-500">Decimals</label>
                  <input 
                    type="text" 
                    value={formData.decimals}
                    onChange={(e) => setFormData({...formData, decimals: e.target.value})}
                    placeholder="18" 
                    className="industrial-input" 
                  />
               </div>
               <div className="col-span-2 flex items-center gap-4 p-4 border border-industrial-gray-200">
                  <input 
                    type="checkbox" 
                    id="autoVerify"
                    className="w-4 h-4 accent-black" 
                  />
                  <label htmlFor="autoVerify" className="text-[10px] font-black uppercase tracking-widest text-industrial-gray-500 cursor-pointer">
                    Enable Auto-Verification on Etherscan
                  </label>
               </div>
            </div>
          </section>

          {/* Vesting Schedules */}
          <section className="space-y-8">
            <div className="space-y-2">
              <h2 className="heading-md">Vesting Schedules</h2>
              <p className="text-xs text-industrial-gray-500 font-medium">Configure lock-ups and release mechanisms for core contributors and treasury.</p>
            </div>

            <div className="space-y-4">
              {[
                { name: "CORE DEVELOPMENT", pct: "25%", cliff: "12 Months" },
                { name: "PUBLIC LIQUIDITY", pct: "50%", cliff: "0 Months (TGE)" }
              ].map((v) => (
                <div key={v.name} className="industrial-card p-6 flex justify-between items-center group hover:border-black transition-colors">
                  <div className="grid grid-cols-3 gap-12 items-center flex-1">
                    <div className="space-y-1">
                      <div className="text-[8px] font-black text-industrial-gray-500 uppercase tracking-widest">Allocation Name</div>
                      <div className="text-xs font-bold uppercase tracking-tight">{v.name}</div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-[8px] font-black text-industrial-gray-500 uppercase tracking-widest">Percentage</div>
                      <div className="text-xs font-bold uppercase tracking-tight">{v.pct}</div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-[8px] font-black text-industrial-gray-500 uppercase tracking-widest">Cliff Period</div>
                      <div className="text-xs font-bold uppercase tracking-tight">{v.cliff}</div>
                    </div>
                  </div>
                  <button className="p-2 text-industrial-gray-500 hover:text-black opacity-0 group-hover:opacity-100 transition-opacity">
                    <PenLine className="w-4 h-4" />
                  </button>
                </div>
              ))}

              <button className="w-full border-2 border-dashed border-industrial-gray-200 p-6 flex items-center justify-center gap-3 text-industrial-gray-500 hover:border-black hover:text-black transition-all uppercase font-black text-[10px] tracking-widest">
                 <Plus className="w-4 h-4" />
                 Add Allocation
              </button>
            </div>
          </section>

          {/* Actions */}
          <div className="pt-12 border-t border-industrial-gray-200 flex justify-between items-center">
             <button 
                onClick={() => step > 1 && setStep(step - 1)}
                disabled={step === 1}
                className={`flex items-center gap-2 text-[10px] font-black uppercase tracking-widest transition-colors ${step === 1 ? 'opacity-0 pointer-events-none' : 'text-industrial-gray-500 hover:text-black'}`}
             >
                <ArrowLeft className="w-4 h-4" />
                Previous Step
             </button>
             
             {!account ? (
               <button 
                  onClick={connectWallet}
                  className="industrial-button-primary flex items-center gap-4"
               >
                  <Wallet className="w-5 h-5" />
                  Connect Wallet
               </button>
             ) : (
               <button 
                  onClick={() => {
                    if (step < 3) setStep(step + 1);
                    else handleDeploy();
                  }}
                  disabled={loading}
                  className="industrial-button-primary flex items-center gap-4"
               >
                  {loading ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <>
                      {step === 3 ? "Finalize & Deploy" : step === 2 ? "Review Configuration" : "Next: Distribution"}
                      <ArrowRight className="w-5 h-5" />
                    </>
                  )}
               </button>
             )}
          </div>
          
          <AnimatePresence>
            {status.message && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`p-4 border text-xs font-bold uppercase tracking-wider ${
                  status.type === "error" ? "bg-industrial-crimson/10 border-industrial-crimson/20 text-industrial-crimson" : "bg-industrial-emerald/10 border-industrial-emerald/20 text-industrial-emerald"
                }`}
              >
                {status.message}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Sidebar Column */}
        <aside className="space-y-8">
           {/* Signer Selection */}
           <div className="industrial-card p-6 space-y-6 border-l-4 border-l-industrial-emerald bg-industrial-emerald/5">
              <div className="text-[10px] font-black uppercase tracking-widest text-industrial-gray-500">Signing Vector</div>
              <div className="flex flex-col gap-3">
                 <button 
                   onClick={() => setUseSystemSigner(false)}
                   className={`flex items-center justify-between p-3 border transition-all ${!useSystemSigner ? 'bg-white border-black shadow-sm' : 'border-industrial-gray-200 text-industrial-gray-400 hover:border-black/30'}`}
                 >
                    <div className="flex items-center gap-3">
                       <Wallet className="w-4 h-4" />
                       <span className="text-[10px] font-black uppercase tracking-tight">MetaMask (Browser)</span>
                    </div>
                    {!useSystemSigner && <CheckCircle2 className="w-3 h-3 text-industrial-emerald" />}
                 </button>
                 <button 
                   onClick={() => setUseSystemSigner(true)}
                   className={`flex items-center justify-between p-3 border transition-all ${useSystemSigner ? 'bg-white border-black shadow-sm' : 'border-industrial-gray-200 text-industrial-gray-400 hover:border-black/30'}`}
                 >
                    <div className="flex items-center gap-3">
                       <Terminal className="w-4 h-4" />
                       <span className="text-[10px] font-black uppercase tracking-tight">System Signer (Local)</span>
                    </div>
                    {useSystemSigner && <CheckCircle2 className="w-3 h-3 text-industrial-emerald" />}
                 </button>
              </div>
              <p className="text-[9px] font-medium text-industrial-gray-500 leading-tight">
                {useSystemSigner 
                  ? "Broadcast using the RPC and Private Key defined in your vault settings." 
                  : "Standard browser-based signing via your connected Metamask vault."}
              </p>
           </div>

           <div className="industrial-card p-6 space-y-8 border-2 border-industrial-gray-200">
              <div className="flex justify-between items-center">
                 <div className="text-[10px] font-black uppercase tracking-widest text-industrial-gray-500">Asset Preview</div>
                 <div className="bg-industrial-emerald/20 text-industrial-emerald px-2 py-0.5 text-[8px] font-black uppercase tracking-widest">Draft</div>
              </div>

              <div className="aspect-video bg-black p-8 text-white flex flex-col justify-end relative overflow-hidden">
                 <div className="space-y-1 relative z-10">
                    <div className="text-4xl font-black italic uppercase tracking-tighter leading-none">{formData.symbol || "INDS"}</div>
                    <div className="text-[10px] font-black uppercase tracking-widest opacity-40">{formData.name || "Industrial Protocol"}</div>
                 </div>
                 <div className="absolute top-0 right-0 p-8 opacity-10">
                    <Zap className="w-24 h-24" />
                 </div>
              </div>

              <div className="space-y-4 pt-4">
                 <div className="flex justify-between items-center border-b border-industrial-gray-100 pb-4">
                    <span className="text-[10px] font-black uppercase tracking-widest text-industrial-gray-500">Protocol Type</span>
                    <span className="text-xs font-bold uppercase tracking-tight">ERC-20 (Standard)</span>
                 </div>
                 <div className="flex justify-between items-center border-b border-industrial-gray-100 pb-4">
                    <span className="text-[10px] font-black uppercase tracking-widest text-industrial-gray-500">Network</span>
                    <span className="text-xs font-bold uppercase tracking-tight">Ethereum Sepolia</span>
                 </div>
                 <div className="flex justify-between items-center">
                    <span className="text-[10px] font-black uppercase tracking-widest text-industrial-gray-500">Est. Deployment Cost</span>
                    <span className="text-xs font-bold uppercase tracking-tight text-industrial-crimson">0.45 ETH</span>
                 </div>
              </div>

              <div className="h-1 bg-black w-full" />

              <p className="text-xs italic font-medium text-industrial-gray-500 leading-relaxed">
                "Precision is the hallmark of the industrial age. Your asset configuration will be immutable once broadcast to the ledger."
              </p>
           </div>

           <div className="grid grid-cols-1 gap-4">
              <div className="industrial-card p-6 flex items-start gap-4">
                 <ShieldCheck className="w-5 h-5 text-industrial-emerald" />
                 <div className="space-y-1">
                    <div className="text-[8px] font-black uppercase tracking-widest text-industrial-gray-500">Audited Code</div>
                    <p className="text-[9px] font-medium text-industrial-gray-500 leading-tight">All Decrypto Forge templates are pre-audited by OpenZeppelin.</p>
                 </div>
              </div>
              <div className="industrial-card p-6 flex items-start gap-4">
                 <Zap className="w-5 h-5 text-industrial-cyan" />
                 <div className="space-y-1">
                    <div className="text-[8px] font-black uppercase tracking-widest text-industrial-gray-500">Minting Rights</div>
                    <p className="text-[9px] font-medium text-industrial-gray-500 leading-tight">Control address is set to your connected wallet by default.</p>
                 </div>
              </div>
           </div>
        </aside>
      </div>
    </div>
  );
}
